<?php
ob_start();
session_start();                                      //on démarre la session pour pouvoir utiliser les variables de session

if (!isset($_SESSION['pseudo'])) {                    //si la variable de session n'existe pas ( si l'utilisateur n'est pas connecté)
    header('Location: index.php');                    //on redirige vers la page de connexion
}


require_once("dao.php");                                             //on fait la jonction avec le fichier DAO
$dao = new DAO();                                                    //on crée une nouvelle instance de DAO
$dao->connexion();                                                   //on se connecte à la BDD





ob_end_flush();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Greengarden</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="main.css">
</head>


<body>

    <header>
        <nav class="navbar navbar-expand-lg bg-dark mb-5">
            <div class="container-fluid">
                <a class="navbar-brand text-white" href="">GreenGarde</a>

                <div class="collapse navbar-collapse " id="navbarSupportedContent">

                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                        <?php if (isset($_SESSION['pseudo']) && $_SESSION['user_type'] == 2) { ?>
                            <li class="nav-item">
                                <a class="nav-link text-white" href="admin.php">Admin</a>
                            </li>
                        <?php } ?>

                        <?php if (isset($_SESSION['pseudo']) == true) { ?>
                            <li class="nav-item">
                                <a class="nav-link text-white" href="produits.php">produit</a>
                            </li>
                        <?php } ?>
                    </ul>

                    <?php if (isset($_SESSION['pseudo']) == false) { ?>
                        <a style="color:white;" href="inscription.php">Inscription</a>
                    <?php } else { ?>
                        <a style="color:red;" class="d-flex justify-content-center " title="Cliquez ici pour vous déconnecter" href='deco.php'>Déconnexion</a>

                    <?php } ?>
                </div>
            </div>
        </nav>
    </header>

    <main>

        <form method="POST" class="mb-3">
            <label for="categorie">Filtrer par catégorie :</label>
            <select name="categorie" id="categorie" class="form-select">
                <option value="0">Toutes les catégories</option>
                <?php

                $categories = $dao->getResults("SELECT * FROM t_d_categorie");

                foreach ($categories as $categorie) {
                    echo '<option value="' . $categorie['Id_Categorie'] . '">' . $categorie['Libelle'] . '</option>';
                }
                ?>
            </select>
            <button type="submit" class="btn btn-primary">Filtrer</button>
        </form>


        <section class="container d-flex flex-row flex-wrap">
            <?php
            // Récupère les produits depuis la base de données
            $categorieFiltre = isset($_POST['categorie']) ? $_POST['categorie'] : 0; // 0 signifie "Toutes les catégories"

            if ($categorieFiltre == 0) {
                $products = $dao->getProduct();
            } else {
                $query = "SELECT * FROM t_d_produit WHERE Id_Categorie = $categorieFiltre";
                $products = $dao->getResults($query);
            }

            // Affiche les produits en utilisant la fonction générique
            foreach ($products as $product) {
                $dao->autoCard($product);
            }
            ?>
        </section>
    </main>


    <footer class=" text-center mt-auto py-3 ">
        <div class="text-center p-3">
            <a>Site réalisé par Paul Boufflers - afpa 2023</a>
        </div>
    </footer>






    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>