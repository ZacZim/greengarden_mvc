<?php
ob_start();
session_start();

require_once("dao.php");                                             //on fait la jonction avec le fichier DAO
$dao = new DAO();                                                         //on crée une nouvelle instance de DAO
$dao->connexion();                                                        //on se connecte à la BDD

$IdentifiantsErr = "";                                                      //on crée une variable pour stocker les messages d'erreur si les identifiants sont incorrects
$IdentifiantsInexistant = "";                                               //on crée une variable pour stocker les messages d'erreur si les identifiants n'existent pas



ob_end_flush();
?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="main/css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital@1&display=swap" rel="stylesheet">
</head>

<body>


    <header>
        <nav class="navbar navbar-expand-lg bg-dark mb-5">
            <div class="container-fluid">
                <a class="navbar-brand text-white" href="LoginPage.php">GreenGarden</a>

                <div class="collapse navbar-collapse " id="navbarSupportedContent">

                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <?php if (isset($_SESSION['email']) == true) { ?>
                            <li class="nav-item">
                                <a class="nav-link active text-white" aria-current="page" href="#">Membres</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link text-white" href="index.php">Livres</a>
                            </li>
                        <?php } ?>
                    </ul>

                    <?php if (isset($_SESSION['email']) == false) { ?>
                        <a style="color:white;" href="page_inscription.php">Inscription</a>
                    <?php } else { ?>
                        <a style="color:red;" class="d-flex justify-content-center " title="Cliquez ici pour vous déconnecter" href='deco.php'>Déconnexion</a>

                    <?php } ?>
                </div>
            </div>
        </nav>
    </header>


    <main>
        <div class="mask d-flex align-items-center h-100 gradient-custom-3">

            <div class="container">

                <div class="row d-flex justify-content-center align-items-center h-100">

                    <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                        <div class="card shadow-lg p-3 mb-5 bg-body rounded" style="border-radius: 15px;">

                            <div class="card-body p-5">

                                <h2 style="font-family: 'Poppins', sans-serif; " class="text-uppercase text-center mb-5 fw-bolder">Connexion</h2>



                                <form method="POST">
                                    <div class="col-auto m-3 ">
                                        <input type="text" class="form-control" id="nom" name="nom" placeholder="Entrez votre nom " required>
                                    </div>

                                    <div class="col-auto m-3">
                                        <input type="text" class="form-control" id="prenom" name="prenom" placeholder="Entrez votre prénom" required>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>

</html>