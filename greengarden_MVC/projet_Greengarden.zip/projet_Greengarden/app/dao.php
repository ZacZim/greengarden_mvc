<?php

class DAO
{
    private $host = "127.0.0.1";
    private $user = "root";
    private $password = "";
    private $database = "greengarden";
    private $charset = "utf8";

    //instance courante de la connexion
    private $bdd;

    //stockage de l'erreur éventuelle du serveur mysql
    private $error;

    //constructeur de la classe
    public function __construct()
    {
    }

    //méthode pour récupérer les résultats d'une requête SQL
    public function getResults($query)
    {
        $results = array();

        $stmt = $this->bdd->query($query);

        if (!$stmt) {
            $this->error = $this->bdd->errorInfo();
            return false;
        } else {
            // fetch uniquement PDO associative 
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    /* méthode de connexion à la base de donnée */
    public function connexion()
    {
        try {
            // On se connecte à MySQL
            $this->bdd = new PDO('mysql:host=' . $this->host . ';dbname=' . $this->database . ';charset=' . $this->charset, $this->user, $this->password);
        } catch (Exception $e) {
            // En cas d'erreur, on affiche un message et on arrête tout
            $this->error = 'Erreur : ' . $e->getMessage();
        }
    }

    /* méthode pour fermer la connexion à la base de données */
    public function disconnect()
    {
        $this->bdd = null;
    }


    /*Récuperation de tous les produits dans la BDD */
    public function getProduct()
    {
        $query = "SELECT * FROM t_d_produit";
        return $this->getResults($query);
    }

    // ---------------------------------------------- Produit -----------------------------------------------------


    //Génération des card bootsrap automatique 
    public function autoCard($product)
    {
        echo '<div class="card m-3 d-flex flex-wrap justify-content-center" style="width: 18rem;">';
        echo '<img src="' . $product['Photo'] . '" class="card-img-top" alt="' . $product['Nom_court'] . '">';
        echo '<div class="card-body d-flex flex-column justify-content-center">';
        echo '<h5 class="card-title d-flex justify-content-center mt-2 ">' . $product['Nom_court'] . '</h5>';
        echo '<p class="card-text d-flex justify-content-center">' . $product['Nom_Long'] . '</p>';
        echo '<p class="card-text d-flex justify-content-center">Prix : ' . $product['Prix_Achat'] . ' €</p>';
        echo '<a href="#" class="btn btn-primary">Acheter</a>';

        // Vérification du type d'utilisateur avant d'afficher les boutons et verification de la page pour afficher ou non 
        if (isset($_SESSION['pseudo']) && $_SESSION['user_type'] == 2 && basename($_SERVER['PHP_SELF']) == 'admin.php') {
            echo '<form method="POST">';
            echo '<button type="submit" name="btn_supp" value="' . $product['Id_Produit'] . '" class="btn btn-dark details-btn" >Supprimer</button>';
            echo '<button type="submit" name="btn_modif" value="' . $product['Id_Produit'] . '" class="btn btn-warning details-btn mx-2" >Modifier</button>';
            echo '</form>';
        }
        
        echo '</div>';
        echo '</div>';
    }

    public function insertProduct($param = [])
    {

        $sql = "INSERT INTO t_d_produit(Taux_TVA,Nom_Long, Nom_court, Ref_fournisseur, Photo, Prix_Achat, Id_Fournisseur, Id_Categorie) VALUES(:t_tva, :n_l, :n_c, :r_f, :p, :p_a, :id_f, :id_c)";
        $query = $this->bdd->prepare($sql);
        $query->execute($param);
    }


    public function suppProduct($Id_Produit)
    {
        $sql = "DELETE FROM t_d_produit WHERE Id_Produit LIKE $Id_Produit";
        $this->bdd->query($sql);
    }

  
    public function modifProduct($Id_Produit)
    {
    }




    // ---------------------------------------------- Page_Inscription -----------------------------------------------------





    public function getMailMdp($query)
    {
        $results = array();                             //fonction pour récupérer et parcourir les données de la BDD

        $stmt = $this->bdd->query($query);              //on exécute la requête SQL

        if (!$stmt) {                                   //si la requête ne s'exécute pas, on affiche l'erreur
            $this->error = $this->bdd->errorInfo();     //stockage de l'erreur dans la variable error
            return false;                               //on retourne false
        } else {                                        //sinon, on retourne le résultat de la requête
            // fetch uniquement PDO associative 
            return $stmt->fetch(PDO::FETCH_ASSOC);      //on retourne le résultat de la requête
        }
    }

    //fonction pour vérifier si l'email existe déjà dans la BDD:
    public function checkMail($email)
    {                                                                      //mettre en paramètre l'email stocké en POST    
        $sql = "SELECT * FROM t_d_client WHERE Mail_Client = '$email'";    //requête SQL pour sélectionner l'email dans la BDD
        return $this->getMailMdp($sql);                                    //on retourne le résultat de la requête                                  
    }

    public function checkPseudonyme($pseudonyme)
    {
        $sql = "SELECT * FROM t_d_user WHERE Login = :login";
        $query = $this->bdd->prepare($sql);
        $query->execute([":login" => $pseudonyme]);
        return $query->fetch(PDO::FETCH_ASSOC);
    }


    //Validation des donnes 
    function valid_donnees($donnees)                                        //on crée une fonction pour sécuriser les données du formulaire
    {
        $donnees = htmlentities(stripslashes(trim($donnees)));              //on enlève les espaces, les antislashs et les caractères spéciaux
        return $donnees;                                                    //on retourne les données sécurisées                                           
    }

    public function insertclient($param = [])
    {
        $sql = "INSERT INTO t_d_client(Nom_Societe_Client, Nom_Client, Prenom_Client, Mail_Client, Tel_Client, Id_Commercial, Id_Type_Client) VALUES(:n_s_cli, :n_cli, :p_cli, :m_cli, :t_cli, :id_c, :id_t_cli)";
        $query = $this->bdd->prepare($sql);
        $query->execute($param);
    }


    public function insertUser($param = [])
    {
        $sql = "INSERT INTO t_d_user (id_UserType, Login, Password) VALUES (:id, :log, :pass)";
        $query = $this->bdd->prepare($sql);
        $query->execute($param);
    }


    // ----------------------------------------------  Index -----------------------------------------------------

    public function getLogin($query)
    {
        $results = array();                             //fonction pour récupérer et parcourir les données de la bdd 

        $stmt = $this->bdd->query($query);              //on exécute la requête SQL

        if (!$stmt) {                                   //si la requête ne s'exécute pas, on affiche l'erreur
            $this->error = $this->bdd->errorInfo();     //stockage de l'erreur dans la variable error
            return false;                               //on retourne false
        } else {                                        //sinon, on retourne le résultat de la requête
            // fetch uniquement PDO associative 
            return $stmt->fetch(PDO::FETCH_ASSOC);      //on retourne le résultat de la requête
        }
    }

    public function checkLogin($Pseudonyme)
    {
        $sql = "SELECT * FROM t_d_user WHERE `Login` = '$Pseudonyme' ";
        return $this->getLogin($sql);
    }
}
