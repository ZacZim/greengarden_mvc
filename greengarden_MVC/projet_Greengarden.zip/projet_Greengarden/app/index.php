<?php
ob_start();
session_start();

require_once("dao.php");                                                  //on fait la jonction avec le fichier DAO
$dao = new DAO();                                                         //on crée une nouvelle instance de DAO
$dao->connexion();                                                        //on se connecte à la BDD

$MdpErr = "";                                                             //on crée une variable pour stocker les messages d'erreur si le MDP est incorecte
$IdentifiantsInexistant = "";
$champincorrects = "";                                                    //on crée une variable pour stocker les messages d'erreur si l'identifiant n'existent pas

if ($_POST) {
    if (isset($_POST['button_register'])) {

        $Pseudonyme = $dao->valid_donnees($_POST['pseudo']);
        $mot_de_passe = $dao->valid_donnees($_POST["password"]);

        $loginResult = $dao->checkLogin($Pseudonyme);
        var_dump($loginResult['Id_UserType']);
        
        if ($loginResult > 0) {

            if ($Pseudonyme != $loginResult['Login']) { // Vérifie si le pseudonyme entré ne correspond pas à celui dans la base de données
                $IdentifiantsInexistant = "Ce pseudonyme n'est pas valide"; // Message pour dire que le pseudonyme n'existe pas

            } elseif (!password_verify($mot_de_passe, $loginResult['Password'])) { // Vérifie si le mot de passe lié au pseudonyme existe
                $MdpErr = "Ce mot de passe n'est pas valide"; // Message pour dire que le mot de passe n'est pas le bon 

            } else { // Les deux conditions sont validées 
                $_SESSION['pseudo'] = $Pseudonyme; // On stocke le pseudonyme dans une session 
                $_SESSION['user_type'] = $loginResult['Id_UserType'];
                header("Location: produits.php"); // On redirige l'utilisateur vers la page "produits.php" après la connexion réussie
                exit(); // La fonction exit() assure que le script PHP se termine ici, évitant toute exécution supplémentaire
            }
        } else {
            $champincorrects = "Les informations entrées ne sont pas valides";
        }
    }
}


ob_end_flush();
?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="main/css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital@1&display=swap" rel="stylesheet">
</head>

<body>


    <header>
        <nav class="navbar navbar-expand-lg bg-dark mb-5">
            <div class="container-fluid">
                <a class="navbar-brand text-white" href="index.php">GreenGarden</a>

                <div class="collapse navbar-collapse " id="navbarSupportedContent">

                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                        <?php if (isset($_SESSION['pseudo']) && $_SESSION['user_type'] == 2) { ?>
                            <li class="nav-item">
                                <a class="nav-link text-white" href="admin.php">Admin</a>
                            </li>
                        <?php } ?>



                        <?php if (isset($_SESSION['pseudo']) == true) { ?>

                            <li class="nav-item">
                                <a class="nav-link text-white" href="produits.php">produit</a>
                            </li>
                        <?php } ?>
                    </ul>

                    <?php if (isset($_SESSION['email']) == false) { ?>
                        <a style="color:white;" href="page_inscription.php">Inscription</a>
                    <?php } else { ?>
                        <a style="color:red;" class="d-flex justify-content-center " title="Cliquez ici pour vous déconnecter" href='deco.php'>Déconnexion</a>

                    <?php } ?>
                </div>
            </div>
        </nav>
    </header>


    <main>
        <div class="mask d-flex align-items-center h-100 gradient-custom-3">

            <div class="container">

                <div class="row d-flex justify-content-center align-items-center h-100">

                    <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                        <div class="card shadow-lg p-3 mb-5 bg-body rounded" style="border-radius: 15px;">

                            <div class="card-body p-5">

                                <h2 style="font-family: 'Poppins', sans-serif; " class="text-uppercase text-center mb-5 fw-bolder">Connexion</h2>



                                <form method="POST">

                                    <div class="col-auto m-3">
                                        <input type="text" class="form-control" id="pseudo" name="pseudo" placeholder="Entrez votre Pseudonyme " required>
                                    </div>

                                    <div class="col-auto m-3">
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Entrez votre Mot de passe " required>
                                    </div>

                                    <div class=" d-flex justify-content-center mt-4">
                                        <button type="submit" name="button_register" class="boutonInsc btn btn btn-lg gradient-custom-4 text-body ">Se connecter</button>
                                    </div>

                                    <!-- Affichage des messages  -->
                                    <div class="col-auto m-3 d-flex justify-content-center">
                                        <p><?php echo $MdpErr; ?></p>
                                        <p><?php echo $IdentifiantsInexistant; ?></p>
                                        <p><?php echo $champincorrects; ?></p>
                                    </div>

                                    <p class="text-center text-muted mt-4 mb-0">Vous n'avez pas de compte ? <a href="page_inscription.php" class="fw-bold text-body"><u>S'enregistrer</u></a></p>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>

</html>