<?php
ob_start();

session_start();

require_once("dao.php");
if (isset($_SESSION['pseudo']) == true) {
    header('location: produits.php');
}

$dao = new DAO();
$dao->connexion();

$messageErrorMail = "";
$inscriptionMessage = "";
$messageErrorPseudonyme = "";

if ($_POST) {

    if (isset($_POST['btn_add_user'])) {

        $nom = $dao->valid_donnees($_POST["nom"]);
        $prenom = $dao->valid_donnees($_POST["prenom"]);
        $email = $_POST["email"];
        $tel = $dao->valid_donnees($_POST["tel"]);
        $Pseudonyme = $dao->valid_donnees($_POST['pseudo']);
        $mot_de_passe = $dao->valid_donnees($_POST["password"]);
        $verif_mot_de_passe = $dao->valid_donnees($_POST["verif_mdp"]);

        // Hachage du mot de passe
        $hashed_password = password_hash($mot_de_passe, PASSWORD_DEFAULT);

        // Vérification que les mots de passe correspondent
        if ($mot_de_passe === $verif_mot_de_passe) {

            // Vérification si l'email existe déjà dans la BDD
            $mail = $dao->checkMail($email);

            if ($mail && is_array($mail) && $mail['Mail_Client'] == $email) {
                // Si l'email existe déjà dans la BDD, on affiche un message d'erreur:
                $messageErrorMail = "Cet email est déjà utilisé.";
            } else {
                // Vérification si le pseudonyme existe déjà
                $existingPseudonyme = $dao->checkPseudonyme($Pseudonyme);

                if ($existingPseudonyme) {
                    $messageErrorPseudonyme = "Ce pseudonyme est déjà utilisé.";
                } else {
                    // Appel des fonctions d'insertion
                    $userType = 1;  // Remplacez par l'ID du type client
                    $idcommercial = 3; // Remplacez par l'ID du type sans commercial 
                    $idtypeclient = 1; // Remplacez par l'ID du type Particulier 

                    // Vérification si le numéro de téléphone est renseigné
                    $tel = isset($_POST["tel"]) ? $dao->valid_donnees($_POST["tel"]) : null;

                    $dao->insertUser(["id" => 1, "log" => $Pseudonyme, "pass" => $hashed_password]);
                    $dao->insertclient(["n_s_cli" => null, "n_cli" => $nom, "p_cli" => $prenom, "m_cli" => $email, "t_cli" => $tel, "id_c" => $idcommercial, "id_t_cli" => $idtypeclient]);
                    $inscriptionMessage = "Inscription réussie !";
                }
            }
        }
    }
}


ob_end_flush();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="main/css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital@1&display=swap" rel="stylesheet">
</head>

<body>

    <header>
        <nav class="navbar navbar-expand-lg bg-dark mb-5">
            <div class="container-fluid">
                <a class="navbar-brand text-white" href="#">GeenGraden</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active text-white" aria-current="page" href="#"></a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link text-white" href="#"></a>
                        </li>
                    </ul>

                    <a style="color:white;" href="index.php">se connecter</a>

                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="mask d-flex align-items-center h-100 gradient-custom-3">

            <div class="container">

                <div class="row d-flex justify-content-center align-items-center h-100">

                    <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                        <div class="card shadow-lg p-3 mb-5 bg-body rounded" style="border-radius: 15px;">

                            <div class="card-body p-5">

                                <h2 style="font-family: 'Poppins', sans-serif; " class="text-uppercase text-center mb-5 fw-bolder">Inscription</h2>

                                <!-- Formulaire d'inscription -->
                                <form method="POST">

                                    <div class="col-auto m-3 ">
                                        <input type="text" class="form-control" id="nom" name="nom" placeholder="Entrez votre nom " required>
                                    </div>

                                    <div class="col-auto m-3">
                                        <input type="text" class="form-control" id="prenom" name="prenom" placeholder="Entrez votre prénom" required>
                                    </div>

                                    <div class="col-auto m-3">
                                        <input type="text" class="form-control" id="pseudo" name="pseudo" placeholder="Entrez votre Pseudonyme " required>
                                    </div>

                                    <div class="col-auto m-3">
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Entrez votre Email" required>
                                    </div>

                                    <div class="col-auto m-3">
                                        <input type="tel" class="form-control" id="tel" name="tel" placeholder="Entrez votre Numéro de téléphone" required>
                                    </div>

                                    <div class="col-auto m-3">
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Entrez votre Mot de passe " required>
                                    </div>

                                    <div class="col-auto m-3 ">
                                        <input type="password" class="form-control" id="verif_mdp" name="verif_mdp" placeholder="Vérification du Mot de passe" required>
                                    </div>

                                    <div class="col-auto m-3 d-flex justify-content-center">
                                        <input type="submit" value="S'inscrire" name="btn_add_user" class="boutonInsc btn btn btn-lg gradient-custom-4 text-body">
                                    </div>

                                    <!-- Affichage des messages d'inscription -->
                                    <div class="col-auto m-3 d-flex justify-content-center">
                                        <p><?php echo $messageErrorMail; ?></p>
                                        <p><?php echo $inscriptionMessage; ?></p>
                                        <p><?php echo $messageErrorPseudonyme; ?></p>
                                    </div>

                                    <p class="text-center text-muted mt-4 mb-0">Vous avez déjà un compte ? <a href="index.php" class="fw-bold text-body"><u>Se connecter</u></a></p>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer>


    </footer>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>