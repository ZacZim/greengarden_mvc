<?php
ob_start();
session_start();                                                     //on démarre la session pour pouvoir utiliser les variables de session

if (!isset($_SESSION['pseudo']) && $_SESSION['user_type'] != 2 ) {            
    header('Location: index.php');                                          
}

require_once("dao.php");                                             //on fait la jonction avec le fichier DAO
$dao = new DAO();                                                    //on crée une nouvelle instance de DAO
$dao->connexion();                                                   //on se connecte à la BDD


if ($_POST) {
    var_dump($_POST);
    if (isset($_POST['btn-add-product'])) {

        $Taux_TVA = $dao->valid_donnees($_POST["tauxtva"]);
        $Nom_Long = $dao->valid_donnees($_POST["nomlong"]);
        $Nom_court = $dao->valid_donnees($_POST["nomcourt"]);
        $Ref_fournisseur = $dao->valid_donnees($_POST["refproduit"]);
        $Photo = $dao->valid_donnees($_POST["image"]);
        $Prix_Achat = $dao->valid_donnees($_POST["prix"]);
        $Id_fournisseur = $dao->valid_donnees($_POST["fournisseur"]);
        $Id_Categorie = $dao->valid_donnees($_POST["categorie"]);
        $dao->insertProduct(["t_tva" => $Taux_TVA, "n_l" => $Nom_Long, "n_c" => $Nom_court, "r_f" => $Ref_fournisseur, "p" => $Photo, "p_a" => $Prix_Achat, "id_f" => $Id_fournisseur, "id_c" => $Id_Categorie]);
    }
}

if ($_POST) {

    if (isset($_POST['btn_supp'])) {
        $dao->suppProduct($_POST['btn_supp']);
    }

    if (isset($_POST['btn_modif'])) {
        $dao->modifProduct($_POST['btn_modif']);
    }
    header('location: admin.php');
}


ob_end_flush();
?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Greengarden</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="main.css">
</head>


<body>

    <nav class="navbar navbar-expand-lg bg-dark mb-5">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="">GreenGarde</a>

            <div class="collapse navbar-collapse " id="navbarSupportedContent">

                <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                    <?php if (isset($_SESSION['pseudo']) && $_SESSION['user_type'] == 2) { ?>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="admin.php">Admin</a>
                        </li>
                    <?php } ?>

                    <?php if (isset($_SESSION['pseudo']) == true) { ?>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="produits.php">produit</a>
                        </li>
                    <?php } ?>
                </ul>

                <?php if (isset($_SESSION['pseudo']) == false) { ?>
                    <a style="color:white;" href="inscription.php">Inscription</a>
                <?php } else { ?>
                    <a style="color:red;" class="d-flex justify-content-center " title="Cliquez ici pour vous déconnecter" href='deco.php'>Déconnexion</a>

                <?php } ?>
            </div>
        </div>
    </nav>

    <main>
        <section>
            <div class="mb-3">
                <h3>Ajouter un nouveau produit</h3>
                <form method="POST">

                    <div class="mb-3">
                        <input type="number" step="0.01" class="form-control" id="tauxtva" name="tauxtva" placeholder="Taux de TVA" required>
                    </div>

                    <div class="mb-3">
                        <input type="text" class="form-control" id="nomlong" name="nomlong" placeholder="Nom long" required>
                    </div>

                    <div class="mb-3">
                        <input type="text" class="form-control" id="nomcourt" name="nomcourt" placeholder="Nom court" required>
                    </div>

                    <div class="mb-3">
                        <input type="text" class="form-control" id="refproduit" name="refproduit" placeholder="Référence fournisseur" required>
                    </div>

                    <div class="mb-3">
                        <input type="text" class="form-control" id="image" name="image" placeholder="lien HTTPS image" required>
                    </div>

                    <div class="mb-3">
                        <input type="number" step="0.01" class="form-control" id="prix" name="prix" placeholder="Prix du produit" required>
                    </div>



                    <div class="mb-3">
                        <label for="fournisseur" class="form-label">Fournisseur</label>
                        <select class="form-select" id="fournisseur" name="fournisseur" required>

                            <?php
                            // Récupérer les fournisseurs depuis la base de données
                            $fournisseurs = $dao->getResults("SELECT * FROM t_d_fournisseur");

                            // Afficher les fournisseurs dans la liste déroulante
                            foreach ($fournisseurs as $fournisseur) {
                                echo '<option value="' . $fournisseur['Id_Fournisseur'] . '">' . $fournisseur['Nom_Fournisseur'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>



                    <div class="mb-3">
                        <label for="categorie" class="form-label">Catégorie</label>
                        <select class="form-select" id="categorie" name="categorie" required>
                            <?php
                            // Récupérer les catégories depuis la base de données
                            $categories = $dao->getResults("SELECT * FROM t_d_categorie");

                            // Afficher les catégories dans la liste déroulante
                            foreach ($categories as $categorie) {
                                $selected = ($categorie['Id_Categorie'] == $selectedCategoryId) ? 'selected' : '';
                                echo '<option value="' . $categorie['Id_Categorie'] . '" ' . $selected . '>' . $categorie['Libelle'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <button type="submit" class="btn bg-danger" name="btn-add-product">Ajouter</button>
                </form>

            </div>
        </section>

        <section class="container d-flex flex-row flex-wrap">
            <?php
            // Récupère les produits depuis la base de données
            $products = $dao->getProduct();

            // Affiche les produits en utilisant la fonction générique
            foreach ($products as $product) {
                $dao->autoCard($product);
            }
            ?>
        </section>
    </main>

    <footer class=" text-center mt-auto py-3 ">
        <div class="text-center p-3">
            <a>Site réalisé par Paul Boufflers - afpa 2023</a>
        </div>
    </footer>






    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>